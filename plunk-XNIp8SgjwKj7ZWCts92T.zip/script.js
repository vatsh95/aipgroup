// Code goes here

(function() {
  var app = angular.module('store', []);
  var movies = [{
    name: 'People Places Things',
    releaseDay: '14/08/2015',
    Duration: '85 mins',
    Genre: 'Comedy',
    Synopsis: 'sdfasdfasdfsadfasdfsadfasdf',
  }];
  app.controller('StoreController', function($scope,$timeout) {
    var vm = this;
    vm.products = [];
    vm.products = movies;
     $scope.$on('addProduct', function($event,product){
         vm.products.push(product);
         console.log(vm.products);
     })
  });
  app.controller("MovieController", function($rootScope) {
    this.movie = [];
    this.addMovie = function(product) {
      $rootScope.$broadcast('addProduct', product);
    };
  });
   
})();